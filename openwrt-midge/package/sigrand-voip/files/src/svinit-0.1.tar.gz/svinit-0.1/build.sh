#!/bin/bash

mipsel-linux-uclibc-gcc -I./vinetic/include/ -I./tapi/include/ -I./sgatab/ svinit.c -o svinit

