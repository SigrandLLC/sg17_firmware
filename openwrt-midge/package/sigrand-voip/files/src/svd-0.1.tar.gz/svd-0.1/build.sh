#!/bin/sh

curr_path=`pwd`
libab_path=${curr_path}/src/libab
dest_path=${curr_path}/src
asrc_path=${curr_path}/../../

make clean
 
aclocal
autoheader
automake -a --foreign
autoconf

#PKG_CONFIG_PATH=/home/vlad/ata/1.12.7_noglib_nossl/lib/pkgconfig/ \
./configure --host=mipsel-linux-uclibc --build=i686-linux-gnu

cd $libab_path
./build.sh

cd ${curr_path}
make

