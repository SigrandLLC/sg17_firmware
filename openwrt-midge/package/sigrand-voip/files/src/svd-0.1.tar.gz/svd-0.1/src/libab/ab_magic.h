#ifndef __AB_MAGIC_H__
#define __AB_MAGIC_H__

#include "../svd.h"

#ifndef AB_CMAGIC_T
	#define AB_CMAGIC_T void
#endif
typedef AB_CMAGIC_T ab_cmagic_t;
	
#ifndef AB_DMAGIC_T
	#define AB_DMAGIC_T void
#endif
typedef AB_DMAGIC_T ab_dmagic_t;

#endif /* __AB_MAGIC_H__ */
